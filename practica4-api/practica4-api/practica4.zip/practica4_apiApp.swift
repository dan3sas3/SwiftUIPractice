//
//  practica4_apiApp.swift
//  practica4-api
//
//  Created by alumno on 17/02/22.
//

import SwiftUI

@main
struct practica4_apiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
